source setEnv.sh
./gc_logs_management.sh
wlst.sh ./start_admin.py
