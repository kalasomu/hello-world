#!/usr/bin/python

nmConnect(userConfigFile='weblogic','weblogic1','rac1','5555','admin',nmType='plain')

AS_admin=nmServerStatus('AdminServer')
if AS_admin=="SHUTDOWN":
 nmServerStatus('AdminServer')
 print >> f, nmServerStatus('AdminServer')
else:
 nmKill('AdminServer')
 nmServerStatus('AdminServer')
exit()

