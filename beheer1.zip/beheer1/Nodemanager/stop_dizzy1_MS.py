#!/usr/bin/python
nmConnect('weblogic','welcome1','rac1','5555','dizzy1',nmType="plain")
MS_dizzy1=nmServerStatus('dizzy1')
if MS_dizzy1=="RUNNING":
 nmKill('dizzy1')
 nmServerStatus('dizzy1')
else:
 nmServerStatus('dizzy1')
exit()

