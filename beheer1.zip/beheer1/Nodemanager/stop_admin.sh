source setEnv.sh
./gc_logs_management.sh
wlst.sh ./stop_admin.py
