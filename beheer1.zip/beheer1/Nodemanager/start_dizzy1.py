#!/usr/bin/python
nmConnect('weblogic','weblogic1','rac1','5555','dizzy1',nmType="palin")
AS_dizzy1=nmServerStatus('AdminServer')
if AS_dizzy1=="RUNNING":
 print "Admin Server is running!"
else:
 nmStart('AdminServer')
 nmServerStatus('dizzy1')
MS_dizzy1=nmServerStatus('dizzy1')
if MS_dizzy1=="RUNNING":
 print "dizzy1 is running!"
else:
 nmStart('dizzy1')
 nmServerStatus('dizzy1')
exit()
