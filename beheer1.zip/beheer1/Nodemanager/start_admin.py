#!/usr/bin/python


nmConnect(userConfigFile='weblogic','welcome1','rac1','5555','admin',nmType='plain')

AS_admin=nmServerStatus('AdminServer')
if AS_admin=="RUNNING":
 print "Admin Server is running!"
else:
 nmStart('AdminServer')
 nmServerStatus('AdminServer')

exit()

