#!/bin/sh
# move
 export GCLOGDIR=/home/oracle10g/gc
 export dt=`date +%Y%m%d%H%M%S`

 cd $GCLLOGDIR
 for filename in $GCLOGDIR/*/*.gc; do
 mv $filename $filename.$dt
 touch $filename
 done

 # remove old# tar
 find $GCLOGDIR -type f -mtime +7 -exec rm {} \;

~

