#!/bin/sh
cd /home/oracle10g/fmw/user_projects/domains/devdomain/bin
nohup ./startWebLogic.sh &
