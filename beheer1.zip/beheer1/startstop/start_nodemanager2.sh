#!/bin/sh
cd /home/oracle10g/fmw/wlserver_10.3/server/bin/
nohup ./startNodeManager.sh 192.168.56.2 5556 &
