#!/bin/sh
cd /home/oracle10g/fmw/user_projects/domains/devdomain/bin
export JAVA_OPTIONS="-Dweblogic.management.username=weblogic -Dweblogic.management.password=welcome1"
nohup ./startManagedWebLogic.sh dizzy3 192.168.56.2:7001 &
