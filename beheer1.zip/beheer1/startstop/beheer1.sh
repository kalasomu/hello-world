#!/bin/sh
check_state() {
        pidnodman1=`ps -fu oracle10g|grep java|grep weblogic.NodeManager|grep DListenPort=5555|awk '{print $2}'`
        pidnodman2=`ps -fu oracle10g|grep java|grep weblogic.NodeManager|grep DListenPort=5556|awk '{print $2}'`
        pidadmin=`ps -fu oracle10g|grep java|grep Dweblogic.Name=AdminServer|awk '{print $2}'`
        piddizzy1=`ps -fu oracle10g|grep java|grep dizzy1|awk '{print $2}'`
        piddizzy2=`ps -fu oracle10g|grep java|grep dizzy2|awk '{print $2}'`
        piddizzy3=`ps -fu oracle10g|grep java|grep dizzy3|awk '{print $2}'`
        if [[ -z $pidnodman1 ]]; then
                nodman1state="Down"
        else
                nodman1state="Running"
        fi
        if [[ -z $pidnodman2 ]]; then
                nodman2state="Down"
        else
                nodman2state="Running"
        fi
        if [[ -z $pidadmin ]]; then
                 adminstate="Down"
                else
                 adminstate="Running"
        fi
        if [[ -z $piddizzy1 ]]; then
                dizzy1state="Down"
        else
                dizzy1state="Running"
        fi
        if [[ -z $piddizzy2 ]]; then
                dizzy2state="Down"
        else
                dizzy2state="Running"
        fi
        if [[ -z $piddizzy3 ]]; then
                dizzy3state="Down"
        else
                dizzy3state="Running"
        fi
        adminnmstate=`cat /home/oracle10g/fmw/beheer/startstop/serverstate-admin`
        dizzy1nmstate=`cat /home/oracle10g/fmw/beheer/startstop/serverstate-dizzy1`
        dizzy2nmstate=`cat /home/oracle10g/fmw/beheer/startstop/serverstate-dizzy2`
        dizzy3nmstate=`cat /home/oracle10g/fmw/beheer/startstop/serverstate-dizzy3`

}
nodman1_start() {
        check_state
        if [ "$nodman1state" = "Down" ]; then 
              sh /home/oracle10g/fmw/beheer1/startstop/start_nodemanager1.sh
              sleep 1 
        fi
}
nodman1_stop() {
        check_state
        if [ "$nodman1state" = "Running" ]; then
              kill -9 $pidnodman1
              sleep 1
        fi
}
nodman1 () {
	check_state
	if [ "$nodman1state" = "Running" ]; then
		echo -n "Do you want to STOP the Nodemanager1?  (y/n/r) "
		read yn
		case $yn in
			y) nodman1_stop ;;
			r) nodman1_stop && echo && sleep 3 && nodman1_start ;;
			*) echo "Back to menu.."
			sleep 1 ;;
		esac
	else
		echo -n "Do you want to START the Nodemanager1?  (y/n) "
		read yn
		if [ "$yn" = "y" ]; then
			nodman1_start
		else
			echo "Back to menu.."
			sleep 1
		fi
	fi
}

nodman2 () {
	check_state
	if [ "$nodman2state" = "Running" ]; then
		echo -n "Do you want to STOP the Nodemanager2?  (y/n/r) "
		read yn
		case $yn in
			y) nodman2_stop ;;
			r) nodman2_stop && echo && sleep 3 && nodman2_start ;;
			*) echo "Back to menu.."
			sleep 1 ;;
		esac
	else
		echo -n "Do you want to START the Nodemanager2?  (y/n) "
		read yn
		if [ "$yn" = "y" ]; then
			nodman2_start
		else
			echo "Back to menu.."
			sleep 1
		fi
	fi
}

nodman2_start () {
	check_state
	if [ "$nodman2state" = "Down" ]; then
		sh /home/oracle10g/fmw/beheer1/startstop/start_nodemanager2.sh
		sleep 1
	fi
}
	
nodman2_stop () {
	check_state
	if [ "$nodman2state" = "Running" ]; then
		kill -9 $pidnodman2
		sleep 1
	fi
}

admin () {
	check_state
if [ "$adminstate" = "Running" ]; then
		echo -n "Do you want to STOP the Admin server?  (y/n/r) "
		read yn
		case $yn in
			y) admin_stop ;;
			r) admin_stop && echo && sleep 3 && admin_start ;;
			*) echo "Back to menu.."
			sleep 1 ;;
		esac
	else
		echo -n "Do you want to START the Admin server?  (y/n) "
		read yn
		if [ "$yn" = "y" ]; then
			admin_start
		else
			echo "Back to menu.."
			sleep 1
		fi
	fi
}

admin_start () {
	check_state
	if [ "$adminstate" = "Down" ]; then
		sh /home/oracle10g/fmw/beheer1/startstop/start_admin.sh
		sleep 1
	fi
}
	
admin_stop () {
	check_state
	if [ "$adminstate" = "Running" ]; then
		kill -9 $pidadmin
		sleep 1
	fi
}

dizzy1 () {
	check_state
	if [ "$dizzy1state" = "Running" ]; then
		echo -n "Do you want to STOP the dizzy1 server?  (y/n/r) "
		read yn
		case $yn in
			y) dizzy1_stop ;;
			r) dizzy1_stop && echo && sleep 3 && dizzy1_start ;;
			*) echo "Back to menu.."
			sleep 1 ;;
		esac
	else
		echo -n "Do you want to START the dizzy1 server?  (y/n) "
		read yn
		if [ "$yn" = "y" ]; then
			dizzy1_start
		else
			echo "Back to menu.."
			sleep 1
		fi
	fi
}
dizzy1_start () {
	check_state
	if [ "$dizzy1state" = "Down" ]; then
		sh /home/oracle10g/fmw/beheer1/startstop/start_dizzy1.sh
		sleep 1
	fi
}
	
dizzy1_stop () {
	check_state
	if [ "$dizzy1state" = "Running" ]; then
		kill -9 $piddizzy1
		sleep 1
	fi
}

dizzy2 () {
	check_state
	if [ "$dizzy2state" = "Running" ]; then
		echo -n "Do you want to STOP the dizzy2 server?  (y/n/r) "
		read yn
		case $yn in
			y) bipadm_stop ;;
			r) bipadm_stop && echo && sleep 3 && dizzy2_start ;;
			*) echo "Back to menu.."
			sleep 1 ;;
		esac
	else
		echo -n "Do you want to START the dizzy2 server?  (y/n) "
		read yn
		if [ "$yn" = "y" ]; then
			dizzy2_start
		else
			echo "Back to menu.."
			sleep 1
		fi
	fi
}

dizzy2_start () {
	check_state
	if [ "$dizzy2state" = "Down" ]; then
		sh /home/oracle10g/fmw/beheer1/startstop/start_dizzy2.sh
		sleep 1
	fi
}
	
dizzy2_stop () {
	check_state
	if [ "$dizzy2state" = "Running" ]; then
		kill -9 $piddizzy2
		sleep 1
	fi
}

dizzy3 () {
	check_state
	if [ "$dizzy3state" = "Running" ]; then
		echo -n "Do you want to STOP the dizzy3 server?  (y/n/r) "
		read yn
		case $yn in
			y) dizzy3_stop ;;
			r) dizzy3_stop && echo && sleep 3 && dizzy3_start ;;
			*) echo "Back to menu.."
			sleep 1 ;;
		esac
	else
		echo -n "Do you want to START the dizzy3 server?  (y/n) "
		read yn
		if [ "$yn" = "y" ]; then
			dizzy3_start
		else
			echo "Back to menu.."
			sleep 1
		fi
	fi
}

dizzy3_start () {
	check_state
	if [ "$dizzy3state" = "Down" ]; then
		sh /home/oracle10g/fmw/beheer1/startstop/start_dizzy3.sh
		sleep 1
	fi
}
	
dizzy3_stop () {
	check_state
	if [ "$dizzy3state" = "Running" ]; then
		kill -9 $piddizzy3
		sleep 1
	fi
}


start_all () {
	dizzy1_start && dizzy2_start && dizzy3_start 
}

stop_all () {
	dizzy1_stop && dizzy2_stop && dizzy3_stop 
}

start_admin () 
{
	admin_start
}

stop_admin ()
 {
	admin_stop 
}

all_procs(){
	echo -n "Do you want to (re)start or stop all servers?  (start/stop/restart)  "
	read startstop
	case $startstop in
		start) 
			echo -n "Are you sure you want to START all servers?  (y/n) "
			read yn
			if [ "$yn" = "y" ]; then
				start_all
			else
				echo "Back to menu.."
				sleep 1
			fi
		;;
		stop)
			echo -n "Are you sure you want to STOP all servers?  (y/n) "
			read yn
			if [ "$yn" = "y" ]; then
				stop_all
			else
				echo "Back to menu.."
				sleep 1
			fi
		;;
		restart)
			echo -n "Are you sure you want to RESTART all servers?  (y/n) "
			read yn
			if [ "$yn" = "y" ]; then
				stop_all 
				for i in $(seq 10 -1 0);do
					echo -ne "\rServers will be started in $i seconds..  "
					sleep 1
				done
				echo -ne "\rServers will now be started..\n"
				start_all
				sleep 1
			else
				echo "Back to menu.."
				sleep 1
			fi
		;;
		*) 
			echo "Back to menu.."
			sleep 1
			;;
		esac
	}

########################### Script #####################################################################
quit="false"

if [ ! "$1" == "" ]; then
	"$1"
	quit="true"
fi

while [ $quit != "true" ]; do
	clear

        # Menu #
        check_state
        echo "==================================================================="
        echo "     Proces           |  Status       | NmStatus     | PID"
        echo "==================================================================="
        echo " 0.  Nodemanager1  :  $nodman1state                       $pidnodman1"
        echo
        echo " 1.  Nodemanager2  :  $nodman2state                       $pidnodman2"
        echo
        echo -n " 2.  admin      :  " && printf "%-15s" $adminstate     && printf "%-15s" $adminnmstate   && printf "%-10s" $pidadmin   && printf "\n"
        echo -n " 3.  dizzy1     :  " && printf "%-15s" $dizzy1state    && printf "%-15s" $dizzy1nmstate  && printf "%-10s" $piddizzy1  && printf "\n"
        echo -n " 4.  dizzy2     :  " && printf "%-15s" $dizzy2state    && printf "%-15s" $dizzy2nmstate  && printf "%-10s" $piddizzy2  && printf "\n"
        echo -n " 5.  dizzy3     :  " && printf "%-15s" $dizzy3state    && printf "%-15s" $dizzy3nmstate  && printf "%-10s" $piddizzy3  && printf "\n"
        echo
        echo " C. Check/update nmStatus"
        echo " A. All servers"
        echo
        echo " q. Quit"
        echo "==================================================================="
        echo -n "> "
# Read user input #
	read choice
	case $choice in
		0) nodman1 ;;
		1) nodman2 ;;
		2) admin ;;
		3) dizzy1 ;;
		4) dizzy2 ;;
		5) dizzy3 ;;

		[cC] ) checknm.sh ;;
		[aA] ) all_procs ;;
		[qQ] ) quit="true" ;;
		*) echo "Invalid option!"
		sleep 1 ;;
	esac
done
clear
